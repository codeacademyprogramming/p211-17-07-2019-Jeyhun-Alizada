﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
   public static class CategoryList
    {
        private static Category[] categories = new Category[3]
{
            new Category { Name = "Dairy Products" },
            new Category { Name = "Meat Products" },
            new Category { Name = "Bakery Products" }
};

        public static Category[] GetCategories() => categories;
    }
}
