﻿namespace WindowsFormsApp1
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWellcome = new System.Windows.Forms.Label();
            this.lbProducts = new System.Windows.Forms.ListBox();
            this.lbCategories = new System.Windows.Forms.Label();
            this.cmbCotegory = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblWellcome
            // 
            this.lblWellcome.AutoSize = true;
            this.lblWellcome.BackColor = System.Drawing.Color.Maroon;
            this.lblWellcome.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWellcome.ForeColor = System.Drawing.Color.White;
            this.lblWellcome.Location = new System.Drawing.Point(293, 31);
            this.lblWellcome.Name = "lblWellcome";
            this.lblWellcome.Size = new System.Drawing.Size(154, 21);
            this.lblWellcome.TabIndex = 1;
            this.lblWellcome.Text = "Wellcome, Admin";
            this.lblWellcome.Click += new System.EventHandler(this.LblWellcome_Click);
            // 
            // lbProducts
            // 
            this.lbProducts.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbProducts.Font = new System.Drawing.Font("Centaur", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProducts.FormattingEnabled = true;
            this.lbProducts.ItemHeight = 24;
            this.lbProducts.Location = new System.Drawing.Point(0, 0);
            this.lbProducts.Name = "lbProducts";
            this.lbProducts.Size = new System.Drawing.Size(214, 414);
            this.lbProducts.TabIndex = 2;
            // 
            // lbCategories
            // 
            this.lbCategories.AutoSize = true;
            this.lbCategories.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCategories.Location = new System.Drawing.Point(235, 67);
            this.lbCategories.Name = "lbCategories";
            this.lbCategories.Size = new System.Drawing.Size(116, 18);
            this.lbCategories.TabIndex = 3;
            this.lbCategories.Text = "Select Category";
            // 
            // cmbCotegory
            // 
            this.cmbCotegory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCotegory.FormattingEnabled = true;
            this.cmbCotegory.Location = new System.Drawing.Point(238, 107);
            this.cmbCotegory.Name = "cmbCotegory";
            this.cmbCotegory.Size = new System.Drawing.Size(161, 21);
            this.cmbCotegory.TabIndex = 4;
            this.cmbCotegory.SelectedIndexChanged += new System.EventHandler(this.CmbCotegory_SelectedIndexChanged);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 414);
            this.Controls.Add(this.cmbCotegory);
            this.Controls.Add(this.lbCategories);
            this.Controls.Add(this.lbProducts);
            this.Controls.Add(this.lblWellcome);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWellcome;
        private System.Windows.Forms.ListBox lbProducts;
        private System.Windows.Forms.Label lbCategories;
        private System.Windows.Forms.ComboBox cmbCotegory;
    }
}