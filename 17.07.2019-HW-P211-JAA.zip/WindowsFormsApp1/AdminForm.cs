﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AdminForm : Form
    {
        Product[] products;
        Category[] categories;

        public AdminForm()
        {
            InitializeComponent();
        }

        private void LblWellcome_Click(object sender, EventArgs e)
        {

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            products = ProductList.GetProducts();
            foreach (Product product in products)
            {
                lbProducts.Items.Add(product.Name);
            }
            categories = CategoryList.GetCategories();
            foreach (Category category in categories)
            {
                cmbCotegory.Items.Add(category.Name);
            }
        }

        private void CmbCotegory_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbProducts.Items.Clear();
            foreach (Category category in categories)
            {
                if (cmbCotegory.Text == category.Name)
                {
                    string myCId = category.Id;
                    foreach (Product product in products)
                    {
                        if (product.CategoryId == myCId)
                        {
                            lbProducts.Items.Add(product.Name);
                        }
                    }
                }
            }
        }
    }
}
